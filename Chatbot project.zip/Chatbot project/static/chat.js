document.addEventListener("DOMContentLoaded", function () {
    const inputField = document.getElementById("userInput");
    const sendButton = document.getElementById("sendButton");
    const chatbox = document.getElementById("chatbox");
    const fileInput = document.getElementById("imageUpload");

    const micButton = document.createElement("button");
    micButton.id = "micButton";
    micButton.innerText = "🎤";
    micButton.style.marginLeft = "10px";
    micButton.style.cursor = "pointer";
    micButton.style.border = "none";
    micButton.style.background = "transparent";
    micButton.style.fontSize = "1.2rem";
    sendButton.parentNode.insertBefore(micButton, sendButton.nextSibling);

    micButton.onclick = () => {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = "en-US";
        recognition.start();

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            fetch("/voice_input", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ voice: transcript })
            })
            .then(res => res.json())
            .then(data => {
                updateChat(transcript, "userText");
                updateChat(data.response, "botText");
                const audio = new Audio(`/static/response.mp3?${new Date().getTime()}`);
                audio.play();
            })
            .catch(err => console.error("Voice input failed:", err));
        };

        recognition.onerror = (e) => console.error("Mic error:", e.error);
    };

    sendButton.onclick = () => sendMessage();
    inputField.addEventListener("keypress", e => {
        if (e.key === "Enter") {
            e.preventDefault();
            sendMessage();
        }
    });

    function sendMessage() {
        const msg = inputField.value.trim();
        const file = fileInput.files[0];
        if (!msg && !file) return;

        if (file) {
            const formData = new FormData();
            formData.append("image", file);
            fetch("/upload_image", {
                method: "POST",
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                updateChat("📤 Image uploaded!", "userText");
                updateChat(data.response, "botText");
                fileInput.value = "";
            });
            return;
        }

        inputField.value = "";
        updateChat(msg, "userText");

        fetch("/message", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: msg })
        })
        .then(res => res.json())
        .then(data => updateChat(data.response, "botText"));
    }

    function updateChat(text, className) {
        const p = document.createElement("p");
        p.className = className;
        const span = document.createElement("span");
        span.innerHTML = text;
        p.appendChild(span);
        chatbox.appendChild(p);
        chatbox.scrollTop = chatbox.scrollHeight;
    }
});
